# RestaurantManagement
Restaurant management project is a system being built to allow easy restaurant management with features like order management, inventory management, reporting analytics and menu management.

## Team : 
###### Milind Gokhale | Vimalendu Shekhar | Shrijit Pillai | Akshay Jarandikar | Megha Mukim | Shruthi Katapalli

## Project: 
We Developed an application on Salesforce Platform that will automate the order placement, order tracking and inventory management in a restaurant. The application increases customer satisfaction level by decreasing the waiting time and facilitating faster delivery of the placed orders. The application could also generate reports that identify the most selling items and the profit generated.

All the functionalities required extensive programming in Java, Javascript, Jquery and twitter-bootstrap.

#### Technologies Used: 
###### Salesforce.com | data.com | Visualforce | JQuery | Javascript | twitter-bootstrap
